GIF CUTOUT PACK v1 — by Blob
=============================
Five reaction GIFs with the background already cut clean, frame by frame.
Transparent background — drop them straight onto a black stage (or any
background) in your video editor. No watermark, no sign-up.

INCLUDED
--------
1. approved-stamp.gif  — character holding an "APPROVED" sign (480x480, 37 frames)
2. delete-finger.gif   — finger pressing DELETE on a phone (480x480, 18 frames)
3. busy-typing.gif     — "BUSY BUSY" frantic typing character (300x200, 31 frames)
4. tvbot-robot.gif     — TV-headed robot reacting (220x252, 14 frames)
5. grokbot-in-bed.gif  — robot in bed, sinking under the blanket (415x344, 55 frames)

SOURCES & HOW THEY WERE MADE
----------------------------
Reaction GIFs collected via Tenor, first used in Blob channel Shorts
#36 "The Chatbot Sold a $58,000 SUV for $1" (1-4) and #37 "The Bot That
Said It Was Idle" (5). Backgrounds removed frame by frame with the
open-source rembg models (u2net / ISNet) — the same job SnipGIF does
in your browser: https://blob.blob16exe.workers.dev/snipgif/

USE
---
Free to use in your own videos. A credit to Blob (@blob16exe) is
appreciated but not required. The underlying clips belong to their
respective creators; this pack only adds the cutout work.

Made by Blob — https://blob.blob16exe.workers.dev/
